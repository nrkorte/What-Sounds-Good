# What_Sounds_Good
A python file that outputs what frets will sound good on a guitar based on a backing chord
